/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author Igor Wendling
 */


import model.Notificacao;
import model.StatusUsuario;
import model.Usuario;
import repository.INotificacaoRepository;
import repository.IUsuarioRepository;
import java.util.List;
import java.util.Optional;

public class NotificacaoService {

    private final IUsuarioRepository usuarioRepository;
    private final INotificacaoRepository notificacaoRepository;

    public NotificacaoService(IUsuarioRepository usuarioRepository, INotificacaoRepository notificacaoRepository) {
        if (usuarioRepository == null || notificacaoRepository == null) {
            throw new IllegalArgumentException("Os repositórios não podem ser nulos.");
        }
        this.usuarioRepository = usuarioRepository;
        this.notificacaoRepository = notificacaoRepository;
    }

    // =========================================================================
    // US 08: Envio de Notificações (Lógica de Negócio)
    // =========================================================================
    
    /**
     * Envia uma notificação do remetente (Admin) para uma lista de destinatários.
     * O remetente deve ser um Administrador e os destinatários devem estar AUTORIZADOS.
     */
    public void enviarNotificacao(Usuario remetente, List<Integer> idsDestinatarios, String mensagem) {
        // Regra 1: O remetente deve ter perfil de Administrador (US 08 - Critério 1)
        if (!"ADMINISTRADOR".equals(remetente.getTipoPerfil())) {
            throw new IllegalStateException("Apenas administradores podem enviar notificações.");
        }

        if (idsDestinatarios == null || idsDestinatarios.isEmpty()) {
            throw new IllegalArgumentException("A lista de destinatários não pode ser vazia.");
        }
        
        // Simplesmente itera e salva uma notificação para cada destinatário.
        for (Integer idDestinatario : idsDestinatarios) {
            Optional<Usuario> optDestinatario = usuarioRepository.buscarPorId(idDestinatario);
            
            // Regra 2: O destinatário deve existir e estar autorizado (US 08 - Critério 2)
            if (optDestinatario.isEmpty()) {
                // Em um sistema real, você registraria este erro no log e continuaria.
                System.err.println("Destinatário ID " + idDestinatario + " não encontrado.");
                continue;
            }
            
            Usuario destinatario = optDestinatario.get();
            if (destinatario.getStatus() != StatusUsuario.AUTORIZADO) {
                // Regra 2: Destinatário não autorizado
                System.err.println("Destinatário ID " + idDestinatario + " não autorizado e será ignorado.");
                continue;
            }

            // Cria e salva a notificação (US 08 - Critério 3)
            Notificacao novaNotificacao = new Notificacao(idDestinatario, mensagem);
            notificacaoRepository.salvar(novaNotificacao);
            
            // Aqui deveria haver um registro de log de sucesso (US 08 - Critério 4)
            // Lembrete: O registro de log será feito mais tarde com o componente externo.
        }
    }

    // =========================================================================
    // US 09: Visualização e Marcação
    // =========================================================================
    
    /**
     * Marca uma notificação específica como lida pelo ID.
     * O usuário autenticado deve ser o dono da notificação (segurança).
     */
    public void marcarComoLida(int idNotificacao, int idUsuarioAutenticado) {
        Optional<Notificacao> optNotificacao = notificacaoRepository.buscarPorId(idNotificacao);

        if (optNotificacao.isEmpty()) {
            throw new IllegalArgumentException("Notificação não encontrada.");
        }
        
        Notificacao notificacao = optNotificacao.get();

        // Regra de Segurança: A notificação só pode ser marcada como lida pelo seu dono (US 09 - Critério 1)
        if (notificacao.getIdDestinatario() != idUsuarioAutenticado) {
             throw new IllegalStateException("Acesso negado. Tentativa de marcar notificação de outro usuário como lida.");
        }
        
        if (!notificacao.isLida()) {
            // Aplica a lógica da Entidade e persiste (US 09 - Critério 4)
            notificacao.ler();
            notificacaoRepository.atualizar(notificacao);
            
            // Aqui deveria haver um registro de log de sucesso (US 09 - Critério 5)
        }
    }
    
    // =========================================================================
    // US 13/10: Consultas de Leitura
    // =========================================================================
    
    /**
     * Retorna todas as notificações de um usuário específico (US 09/13).
     */
    public List<Notificacao> buscarNotificacoesDoUsuario(int idUsuario) {
        // O repositório já garante que apenas as notificações do usuário serão retornadas.
        return notificacaoRepository.buscarTodasPorUsuario(idUsuario);
    }
    
    /**
     * Retorna a contagem de notificações não lidas para o rodapé (US 13).
     */
    public int contarNotificacoesNaoLidas(int idUsuario) {
        return notificacaoRepository.contarNaoLidas(idUsuario);
    }
    
    /**
     * Retorna o total de notificações enviadas e lidas para relatórios (US 10).
     */
    public int contarTotalLidas(int idUsuario) {
        return notificacaoRepository.contarTotalLidas(idUsuario);
    }
    
    public int contarTotalRecebidas(int idUsuario) {
        return notificacaoRepository.contarTotalRecebidas(idUsuario);
    }
}
